#!/bin/bash
set -x

echo "Building is done in downstream jobs!"
