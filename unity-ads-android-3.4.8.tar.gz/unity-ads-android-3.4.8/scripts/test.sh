#!/bin/bash
set -x

echo "Testing is done in downstream jobs!"
