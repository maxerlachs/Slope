package com.unity3d.ads.test;

import com.unity3d.ads.test.integration.banner.BannerIntegrationTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	BannerIntegrationTest.class
})
public class IntegrationTestSuite {
}
