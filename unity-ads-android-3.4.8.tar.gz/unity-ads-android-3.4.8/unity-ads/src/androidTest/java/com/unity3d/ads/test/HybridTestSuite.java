package com.unity3d.ads.test;

import com.unity3d.ads.test.hybrid.HybridTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
  HybridTest.class
})
public class HybridTestSuite {}
