package com.unity3d.ads.test.hybrid;

import android.app.Activity;
import android.os.Bundle;

public class HybridTestActivity extends Activity {
  @Override
  protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }
}
