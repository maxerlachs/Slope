package com.unity3d.services.core.lifecycle;

public enum LifecycleError {
	APPLICATION_NULL,
	LISTENER_NOT_NULL,
	JSON_ERROR
}
