package com.unity3d.services.purchasing.core;

public enum PurchasingError {
    RETRIEVE_PRODUCTS_ERROR,
    PURCHASING_ADAPTER_NULL
}
