package com.unity3d.services.core.request;

public enum WebRequestEvent {
	COMPLETE,
	FAILED
}
