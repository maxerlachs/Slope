package com.unity3d.services.ads.adunit;


public class AdUnitTransparentSoftwareActivity extends AdUnitTransparentActivity {
	// inherit all functionality from AdUnitActivity
}