package com.unity3d.services.ar;

public enum ARError {
	ARCONFIG_INVALID,
	ARVIEW_NULL,
	AR_NOT_SUPPORTED,
	INVALID_VALUE,
}
