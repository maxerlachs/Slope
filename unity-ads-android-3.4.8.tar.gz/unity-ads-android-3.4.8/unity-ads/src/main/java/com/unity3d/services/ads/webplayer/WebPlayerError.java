package com.unity3d.services.ads.webplayer;

public enum WebPlayerError {
	WEBPLAYER_NULL
}
