package com.unity3d.services.core.broadcast;

public enum BroadcastError {
	JSON_ERROR
}