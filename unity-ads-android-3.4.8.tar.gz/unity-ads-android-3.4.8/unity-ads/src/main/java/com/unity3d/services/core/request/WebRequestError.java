package com.unity3d.services.core.request;

public enum WebRequestError {
	MAPPING_HEADERS_FAILED
}
