package com.unity3d.services.ads.adunit;


public class AdUnitSoftwareActivity extends AdUnitActivity {
	// inherit all functionality from AdUnitActivity
}