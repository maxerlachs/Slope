package com.unity3d.services.core.webview.bridge;

public enum CallbackStatus {
	OK,
	ERROR
}
