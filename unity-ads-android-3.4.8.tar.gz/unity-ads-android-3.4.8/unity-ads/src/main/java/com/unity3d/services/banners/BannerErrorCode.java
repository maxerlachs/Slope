package com.unity3d.services.banners;

public enum  BannerErrorCode {
	UNKNOWN,
	NATIVE_ERROR,
	WEBVIEW_ERROR,
	NO_FILL
}
