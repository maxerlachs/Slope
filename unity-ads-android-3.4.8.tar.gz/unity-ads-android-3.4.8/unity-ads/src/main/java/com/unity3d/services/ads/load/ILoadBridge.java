package com.unity3d.services.ads.load;

import java.util.Map;

public interface ILoadBridge {

	void loadPlacements(Map<String, Integer> placements);

}
