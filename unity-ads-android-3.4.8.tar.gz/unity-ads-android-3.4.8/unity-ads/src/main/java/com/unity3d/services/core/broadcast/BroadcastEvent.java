package com.unity3d.services.core.broadcast;

public enum BroadcastEvent {
	ACTION
}