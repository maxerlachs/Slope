package com.unity3d.services.monetization.placementcontent.purchasing;

public enum NativePromoShowType {
    FULL,
    PREVIEW
}
