package com.unity3d.services.core.cache;

public enum CacheDirectoryType {
	EXTERNAL,
	INTERNAL
}
