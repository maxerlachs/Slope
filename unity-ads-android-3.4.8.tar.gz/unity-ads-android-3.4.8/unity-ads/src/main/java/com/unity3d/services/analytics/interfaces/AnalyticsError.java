package com.unity3d.services.analytics.interfaces;

public enum AnalyticsError {
    API_NOT_FOUND
}
