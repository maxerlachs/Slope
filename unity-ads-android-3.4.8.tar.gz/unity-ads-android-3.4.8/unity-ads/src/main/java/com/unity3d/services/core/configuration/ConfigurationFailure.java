package com.unity3d.services.core.configuration;

public enum ConfigurationFailure {
	NETWORK_FAILURE, INVALID_DATA
}
