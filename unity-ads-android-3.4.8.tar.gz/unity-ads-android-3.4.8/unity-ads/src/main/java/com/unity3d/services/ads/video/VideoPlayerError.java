package com.unity3d.services.ads.video;

public enum VideoPlayerError {
	VIDEOVIEW_NULL,
	PREPARE,
	API_LEVEL_ERROR
}
