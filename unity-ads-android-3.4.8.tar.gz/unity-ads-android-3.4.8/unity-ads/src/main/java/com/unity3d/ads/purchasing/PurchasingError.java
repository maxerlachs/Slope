package com.unity3d.ads.purchasing;

public enum PurchasingError {
    PURCHASE_INTERFACE_NULL
}
