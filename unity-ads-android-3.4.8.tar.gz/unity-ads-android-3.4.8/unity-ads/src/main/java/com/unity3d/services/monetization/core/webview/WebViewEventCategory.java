package com.unity3d.services.monetization.core.webview;

public enum WebViewEventCategory {
    PLACEMENT_CONTENT,
    CUSTOM_PURCHASING
}
